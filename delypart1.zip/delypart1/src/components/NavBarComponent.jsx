import {
  Box,
  Grid,
  AppBar,
  Container,
  Typography,
  Paper,
  IconButton,
  Avatar,
  Badge,
  Menu,
  MenuItem,
  Divider,
  ListItemIcon,
  Tooltip,
} from "@mui/material";
import {
  NotificationsOutlined,
  Settings,
  Logout,
  AccountCircleOutlined,
} from "@mui/icons-material";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function NavBarComponent() {
  const [notificationAnchorEl, setNotificationAnchorEl] = useState(null);
  const [anchorEl, setAnchorEl] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false); // Track authentication state
  const open = Boolean(anchorEl);
  const notificationOpen = Boolean(notificationAnchorEl);
  const navigate = useNavigate(); // React Router navigation

  // Check authentication status on page load
  useEffect(() => {
    const token = localStorage.getItem("token"); // Or sessionStorage if you're using session storage
    if (token) {
      setIsAuthenticated(true); // User is logged in
    }
  }, []);

  const handleAvatarClicked = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleNotificationClicked = (event) => {
    setNotificationAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const notificationHandleClose = () => {
    setNotificationAnchorEl(null);
  };

  const handleLogout = () => {
    setIsAuthenticated(false); // Update state to logged out
    localStorage.removeItem("token"); // Clear token from localStorage
    navigate("/"); // Redirect to home page or wherever appropriate
  };

  const handleSignUpClick = () => {
    navigate("/SignUp"); // Navigate to the SignUp page
  };

  return (
    <Grid container>
      <Grid item xs={12}>
        <Paper elevation={4}>
          <AppBar sx={{ padding: 2 }} position="static">
            <Container maxWidth="xxl">
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  flexDirection: { xs: "column", sm: "row" },
                }}
              >
                <Typography
                  variant="h6"
                  component="a"
                  href="/"
                  sx={{
                    mx: 2,
                    display: "block",
                    fontWeight: 700,
                    letterSpacing: ".2rem",
                    color: "inherit",
                    textDecoration: "none",
                    textAlign: "center",
                    width: "100%",
                  }}
                >
                  Fyp Project Name
                </Typography>

                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "flex-end",
                    alignItems: "center",
                    width: "100%",
                    mt: { xs: 2, sm: 0 },
                  }}
                >
                  <IconButton
                    onClick={handleAvatarClicked}
                    size="small"
                    sx={{ mx: 2 }}
                    aria-haspopup="true"
                  >
                    <Tooltip title="Account settings">
                      <Avatar sx={{ width: 32, height: 32 }}>Z</Avatar>
                    </Tooltip>
                  </IconButton>

                  {/* User name (can be replaced with dynamic data) */}
                  <Typography fontFamily={"Inter"}></Typography>
                </Box>

                <Menu
                  open={open}
                  anchorEl={anchorEl}
                  onClick={handleClose}
                  onClose={handleClose}
                >
                  {/* Conditional rendering based on authentication state */}
                  {isAuthenticated ? (
                    <>
                      <MenuItem>
                        <ListItemIcon>
                          <AccountCircleOutlined fontSize="small" />
                        </ListItemIcon>
                        Profile
                      </MenuItem>
                      <Divider />
                      <MenuItem>
                        <ListItemIcon>
                          <Settings fontSize="small" />
                        </ListItemIcon>
                        Settings
                      </MenuItem>
                      <MenuItem onClick={handleLogout}>
                        <ListItemIcon>
                          <Logout fontSize="small" />
                        </ListItemIcon>
                        Logout
                      </MenuItem>
                    </>
                  ) : (
                    <MenuItem onClick={handleSignUpClick}>
                      <ListItemIcon>
                        <AccountCircleOutlined fontSize="small" />
                      </ListItemIcon>
                      Sign Up
                    </MenuItem>
                  )}
                </Menu>
              </Box>
            </Container>
          </AppBar>
        </Paper>
      </Grid>
    </Grid>
  );
}
