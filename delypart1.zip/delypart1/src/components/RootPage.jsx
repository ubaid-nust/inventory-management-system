import React from "react";
import { useMediaQuery, useTheme } from '@mui/material';
// export default function RootPage() {
//   return <div>RootPage</div>;
// }


export default function RootPage() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  return (
    <div>
      {isMobile ? <div>RootPage - Mobile View</div> : <div>RootPage - Desktop View</div>}
    </div>
  );
}
