import { Card, Box, CardContent, Typography } from "@mui/material";

export default function InfoCard({ card }) {
  return (
    //do the routing here
    <>
      <Card elevation={6} sx={{ mx: { xs: 1, sm: card.mx }, my: { xs: 1, sm: card.my }, borderRadius: 2 }}>
        <Box sx={{ display: "flex", alignItems: "center", flexDirection: { xs: "column", sm: "row" } }} pl={1}>
          <Box
            p={1}
            m={2}
            sx={{
              display: "flex",
              bgcolor: "primary.main",
              borderRadius: 2,
              alignItems: "center",
              justifyContent: "center",
              width: { xs: "100%", sm: "auto" },
            }}
          >
            {card.icon}
          </Box>
          <CardContent
            sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: { xs: "center", sm: "flex-start" },
              justifyContent: "center",
              textAlign: { xs: "center", sm: "left" },
            }}
          >
            <Typography variant="h6" color="text.secondary" component="div">
              {card.title}
            </Typography>
            <Typography
              variant="h5"
              fontWeight={"bolder"}
              color="text.secondary"
              component="div"
            >
              {card.subTitle}
            </Typography>
          </CardContent>
        </Box>
      </Card>
    </>
  );
}
