import React from "react";
import { Paper, Typography, Box } from "@mui/material";

const RevenueCard = ({ card }) => {
  return (
    <Paper elevation={3}>
      <Box sx={{ p: 2 }}>
        <Typography variant="h6">{card.title}</Typography>
        <Typography variant="body2">{card.subTitle}</Typography>
        <Typography variant="h5" color={card.color}>
          {card.isMoney ? `$${card.number}` : card.number}
        </Typography>
        {card.percentage && (
          <Typography variant="body2" color={card.upOrDown === "up" ? "green" : "red"}>
            {card.percentage}% {card.upOrDown === "up" ? "Increase" : "Decrease"}
          </Typography>
        )}
      </Box>
    </Paper>
  );
};

export default RevenueCard;