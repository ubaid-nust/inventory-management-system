// RevenueCostChart.js
import React, { useEffect, useState } from "react";
import ApexCharts from "react-apexcharts";
import { Box } from "@mui/material";
import axios from "axios";

export default function RevenueCostChart() {
  const [channelData, setChannelData] = useState([]);

  useEffect(() => {
    // Fetch revenue and cost data from the backend
    const fetchRevenueCostData = async () => {
      try {
        const response = await axios.get("http://localhost:4000/revenueCost");
        const fetchedData = response.data;
        
        // Organize data into series format for the chart
        const revenueData = {
          name: "Revenue",
          type: "column",
          data: fetchedData.map(item => item.revenue),
        };
        const costData = {
          name: "Cost",
          type: "column",
          data: fetchedData.map(item => item.cost),
        };

        setChannelData([revenueData, costData]); // Update state with fetched data
      } catch (error) {
        console.error("Error fetching revenue cost data:", error);
      }
    };

    fetchRevenueCostData();
  }, []);

  const options3 = {
    colors: ["#00D100", "#FF2E2E"],
    chart: {
      id: "basic-bar",
      type: "bar",
      stacked: false, // one on top of another
    },
    dataLabels: {
      enabled: false,
    },
    legend: {
      position: "top",
      horizontalAlign: "center",
      offsetY: 0,
    },
    title: {
      text: "Cost & Revenue over Year",
    },
    plotOptions: {
      bar: {
        columnWidth: "30%",
        horizontal: false,
      },
    },
    fill: {
      opacity: 1,
    },
    xaxis: {
      categories: [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec",
      ],
    },
    tooltip: {
      fixed: {
        enabled: true,
        position: "topLeft", // topRight, topLeft, bottomRight, bottomLeft
        offsetY: 30,
        offsetX: 60,
      },
    },
  };

  return (
    <Box
      sx={{
        marginX: 4,
        bgcolor: "white",
        borderRadius: 2,
        padding: 3,
        height: "95%",
      }}
    >
      <ApexCharts
        options={options3}
        series={channelData}
        type="bar"
        width="100%"
        height="320"
      />
    </Box>
  );
}