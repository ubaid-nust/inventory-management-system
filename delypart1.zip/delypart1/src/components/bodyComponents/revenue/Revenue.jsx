import React, { Component } from "react";
import RevenueCard from "./RevenueCard";
import { Box, Grid, Typography, Paper } from "@mui/material";
import RevenueCostChart from "./RevenueCostChart";
import BestSelledProductChart from "./BestSelledProductChart";
import BestSelledProductChartBar from "./BestSelledProductChartBar";
import axios from "axios";

export default class Revenue extends Component {
  state = {
    revenuCards: [], // Initial state is an empty array for revenue data
  };

  // Fetch data when the component mounts
  componentDidMount() {
    this.fetchRevenueCards();
  }

  // Method to fetch data from the backend API
  fetchRevenueCards = async () => {
    try {
      // Ensure the correct URL for your backend (http://localhost:4000/revenue)
      const response = await axios.get("http://localhost:4000/revenue");
      console.log("Fetched revenue data:", response.data); // For debugging
      this.setState({ revenuCards: response.data }); // Update state with fetched data
    } catch (error) {
      console.error("Error fetching revenue data:", error);
    }
  };

  render() {
    const { revenuCards } = this.state; // Destructure revenue data from state

    return (
      <Box sx={{ p: 3, mx: 3 }}>
        <Grid container sx={{ mx: 4 }}>
          {revenuCards.length > 0 ? (
            revenuCards.map((card, index) => (
              <Grid item md={3} key={index}>
                <Box m={4}>
                  <RevenueCard card={card} />
                </Box>
              </Grid>
            ))
          ) : (
            <Typography>No revenue data available.</Typography>
          )}
        </Grid>

        <Grid container sx={{ mx: 4 }}>
          <Grid item md={12}>
            <RevenueCostChart />
          </Grid>
        </Grid>

        <Grid container sx={{ mx: 4 }}>
          <Grid item md={6}>
            <BestSelledProductChart />
          </Grid>
          <Grid item md={6}>
            <BestSelledProductChartBar />
          </Grid>
        </Grid>
      </Box>
    );
  }
}