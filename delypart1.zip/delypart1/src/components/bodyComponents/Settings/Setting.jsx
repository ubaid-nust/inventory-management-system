import React, { Component } from "react";
import { Container, Row, Col, Card, Button, Form } from "react-bootstrap";
import { FaCogs } from "react-icons/fa";  // Add this if you want to use icons
import './Setting.css'; // Import external CSS file for custom styles (optional)

export default class Setting extends Component {
  render() {
    return (
      <Container className="my-5">
        <Row className="justify-content-center">
          <Col md={8} lg={6}>
            {/* Setting Title */}
            <Card className="shadow-lg setting-card">
              <Card.Header className="bg-primary text-white text-center rounded-top">
                <h3><FaCogs /> Inventory Management System - Settings</h3>
              </Card.Header>
              <Card.Body>
                <h5 className="mb-4 setting-title">Manage System Settings</h5>

                {/* Setting Options */}
                <Form>
                  <Form.Group className="mb-3">
                    <Form.Label>Inventory Threshold</Form.Label>
                    <Form.Control type="number" placeholder="Set inventory low threshold" className="input-field" />
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label>Alert Notification</Form.Label>
                    <Form.Select className="input-field">
                      <option>Select Notification Frequency</option>
                      <option value="1">Daily</option>
                      <option value="2">Weekly</option>
                      <option value="3">Monthly</option>
                    </Form.Select>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label>Currency Format</Form.Label>
                    <Form.Select className="input-field">
                      <option>Choose currency format</option>
                      <option value="usd">$ USD</option>
                      <option value="euro">€ EUR</option>
                      <option value="gbp">£ GBP</option>
                    </Form.Select>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Check type="checkbox" label="Enable Inventory Tracking" className="checkbox-field" />
                  </Form.Group>

                  <div className="text-center">
                    <Button variant="primary" size="lg" type="submit" className="submit-btn">
                      Save Settings
                    </Button>
                  </div>
                </Form>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    );
  }
}
