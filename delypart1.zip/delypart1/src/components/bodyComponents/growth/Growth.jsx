import React, { Component } from "react";
import { Box, Grid } from "@mui/material";
import axios from "axios";
import RevenueCard from "../revenue/RevenueCard";
import VisitorsGrowthCharts from "./VisitorsGrowthCharts";
import ProductsGrowthCharts from "./ProductsGrowthCharts";
import CustomersGrowthCharts from "./CustomersGrowthCharts";
import SalesGrowthCharts from "./SalesGrowthCharts";

export default class Growth extends Component {
  state = {
    revenueCards: [],
  };

  componentDidMount() {
    this.fetchRevenueCards();
  }

  fetchRevenueCards = async () => {
    try {
      const response = await axios.get("http://localhost:4000/revenue-cards");
      this.setState({ revenueCards: response.data });
    } catch (error) {
      console.error("Error fetching revenue cards:", error);
    }
  };

  render() {
    const { revenueCards } = this.state;

    return (
      <Box sx={{ p: 3, mx: 3 }}>
        <Grid container spacing={2}>
          {revenueCards.map((card, index) => (
            <Grid item xs={12} sm={6} md={3} key={index}>
              <Box m={2}>
                <RevenueCard card={card} />
              </Box>
            </Grid>
          ))}
        </Grid>
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <SalesGrowthCharts />
          </Grid>
          <Grid item xs={12} md={6}>
            <VisitorsGrowthCharts />
          </Grid>
        </Grid>
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <ProductsGrowthCharts />
          </Grid>
          <Grid item xs={12} md={6}>
            <CustomersGrowthCharts />
          </Grid>
        </Grid>
      </Box>
    );
  }
}