import React, { useEffect, useState } from "react";
import ApexCharts from "react-apexcharts";
import { Box, useTheme, useMediaQuery } from "@mui/material";
import axios from "axios";

export default function VisitorsGrowthCharts() {
  const [visitorData, setVisitorData] = useState([]);
  const [categories, setCategories] = useState([]);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  useEffect(() => {
    fetchVisitorData();
  }, []);

  const fetchVisitorData = async () => {
    try {
      const response = await axios.get("http://localhost:4000/visitor-growth");
      setCategories(response.data.categories);
      setVisitorData(response.data.series);
    } catch (error) {
      console.error("Error fetching visitor growth data:", error);
    }
  };

  const options3 = {
    colors: ["#A020F0", "#FA6800"],
    chart: {
      id: "basic-bar",
      type: "bar",
      stacked: false,
      height: isMobile ? 300 : 350,
    },
    dataLabels: {
      enabled: false,
    },
    legend: {
      position: "top",
      horizontalAlign: "right",
      offsetY: 0,
    },
    title: {
      text: "Visitors",
    },
    plotOptions: {
      bar: {
        columnWidth: "15%",
        horizontal: false,
        borderRadius: 2,
      },
    },
    fill: {
      opacity: 1,
    },
    xaxis: {
      categories,
    },
    tooltip: {
      fixed: {
        enabled: true,
        position: "topLeft",
        offsetY: 30,
        offsetX: 60,
      },
    },
  };

  return (
    <Box
      sx={{
        marginX: 4,
        bgcolor: "white",
        borderRadius: 2,
        padding: 3,
        height: "100%",
      }}
    >
      <ApexCharts
        options={options3}
        series={visitorData}
        type="bar"
        width="100%"
        height={isMobile ? 300 : 350}
      />
    </Box>
  );
}
