import React, { useEffect, useState } from "react";
import ApexCharts from "react-apexcharts";
import { Box, useTheme, useMediaQuery } from "@mui/material";
import axios from "axios";

export default function ProductsGrowthCharts() {
  const [channelData, setChannelData] = useState([]);
  const [categories, setCategories] = useState([]);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  useEffect(() => {
    fetchProductData();
  }, []);

  const fetchProductData = async () => {
    try {
      const response = await axios.get("http://localhost:4000/product-growth");
      setCategories(response.data.categories);
      setChannelData(response.data.series);
    } catch (error) {
      console.error("Error fetching product growth data:", error);
    }
  };

  const options3 = {
    colors: ["#BF181D", "#FFBF00"],
    chart: {
      id: "basic-bar",
      type: "line",
      height: isMobile ? 300 : 350,
    },
    dataLabels: {
      enabled: false,
    },
    legend: {
      position: "top",
      horizontalAlign: "center",
      offsetY: 0,
    },
    title: {
      text: "Product Growth",
    },
    stroke: {
      width: 3,
      curve: "smooth",
    },
    markers: {
      size: 5,
      strokeWidth: 0,
      hover: {
        size: 7,
      },
    },
    fill: {
      opacity: 1,
    },
    xaxis: {
      categories,
    },
    tooltip: {
      fixed: {
        enabled: true,
        position: "topLeft",
        offsetY: 30,
        offsetX: 60,
      },
    },
  };

  return (
    <Box
      sx={{
        margin: 4,
        bgcolor: "white",
        borderRadius: 2,
        padding: 3,
        height: "95%",
      }}
    >
      <ApexCharts
        options={options3}
        series={channelData}
        type="line"
        width="100%"
        height={isMobile ? "300" : "350"}
      />
    </Box>
  );
}
