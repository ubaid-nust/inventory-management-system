import React, { useEffect, useState } from "react";
import { Box, useTheme, useMediaQuery } from "@mui/material";
import ApexCharts from "react-apexcharts";
import axios from "axios";

export default function SalesGrowthCharts() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const [chartData, setChartData] = useState({ name: "", data: [], categories: [] });

  useEffect(() => {
    fetchChartData();
  }, []);

  const fetchChartData = async () => {
    try {
      const response = await axios.get("http://localhost:4000/sales-growth");
      setChartData(response.data);
    } catch (error) {
      console.error("Error fetching sales growth data:", error);
    }
  };

  const options = {
    chart: {
      id: "basic-bar",
      type: "bar",
      stacked: true,
      height: isMobile ? 300 : 350,
    },
    dataLabels: {
      enabled: true,
    },
    legend: {
      position: "top",
      horizontalAlign: "center",
      offsetY: 0,
    },
    title: {
      text: "Sales Growth Over The Year",
    },
    plotOptions: {
      bar: {
        columnWidth: "40%",
        horizontal: false,
      },
    },
    fill: {
      opacity: 1,
    },
    xaxis: {
      categories: chartData.categories,
    },
    tooltip: {
      fixed: {
        enabled: true,
        position: "topLeft", // topRight, topLeft, bottomRight, bottomLeft
        offsetY: 30,
        offsetX: 60,
      },
    },
  };

  const series = [
    {
      name: chartData.name,
      type: "column",
      data: chartData.data,
    },
  ];

  return (
    <Box
      sx={{
        marginX: 4,
        bgcolor: "white",
        borderRadius: 2,
        padding: 3,
        height: "100%",
      }}
    >
      <ApexCharts
        options={options}
        series={series}
        height={isMobile ? 300 : 350}
        type="bar"
        width="100%"
      />
    </Box>
  );
}
