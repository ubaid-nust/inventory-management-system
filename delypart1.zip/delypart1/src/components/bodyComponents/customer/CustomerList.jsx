import { Component } from "react";
import { Avatar, Box, Typography, CircularProgress, Paper } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import axios from "axios";

export default class CustomerList extends Component {
  state = {
    customers: [],
    loading: true,
    error: null,
  };

  async componentDidMount() {
    try {
      const response = await axios.get("http://localhost:4000/api/customers");
      this.setState({ customers: response.data, loading: false });
    } catch (error) {
      console.error("Error fetching customer data:", error);
      this.setState({ error: "Failed to load customer data", loading: false });
    }
  }

  render() {
    const { customers, loading, error } = this.state;

    const columns = [
      {
        field: "id",
        headerName: "ID",
        flex: 0.5,
        minWidth: 90,
        description: "ID of the customer",
      },
      {
        field: "fullname",
        headerName: "Full Name",
        flex: 1,
        minWidth: 200,
        description: "Customer full name",
        renderCell: (params) => {
          return (
            <>
              <Avatar
                alt="name"
                variant="square"
                sx={{
                  borderRadius: 1,
                  width: 30,
                  height: 30,
                  bgcolor: "#504099", // Color for the Avatar background
                }}
              >
                Z
              </Avatar>
              <Typography variant="subtitle2" sx={{ mx: 3, fontWeight: "bold" }}>
                {`${params.row.firstName || ""} ${params.row.lastName || ""}`}
              </Typography>
            </>
          );
        },
      },
      {
        field: "orderNumber",
        headerName: "Number Of Orders",
        flex: 1,
        minWidth: 200,
        description: "Number of orders the customer made",
        valueGetter: (params) => params.row.orders ? params.row.orders.length : 0,
      },
      {
        field: "mobile",
        headerName: "Mobile",
        flex: 1.5,
        minWidth: 300,
        description: "Customer's mobile number",
      },
    ];

    if (loading) return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
        }}
      >
        <CircularProgress />
      </Box>
    );

    if (error) return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
        }}
      >
        <Typography variant="h6" color="error">
          Error: {error}
        </Typography>
      </Box>
    );

    return (
      <Box
        sx={{
          margin: 3,
          bgcolor: "#f4f6f9", // Light background color for the container
          borderRadius: 2,
          padding: 3,
          height: "100%",
        }}
      >
        <Typography variant="h5" sx={{ marginBottom: 2, color: "#504099", fontWeight: "bold" }}>
          Customer List
        </Typography>
        <Paper elevation={3} sx={{ padding: 2 }}>
          <DataGrid
            sx={{
              borderLeft: 0,
              borderRight: 0,
              borderRadius: 0,
              boxShadow: 2,
              "& .MuiDataGrid-cell:hover": {
                backgroundColor: "#f0f0f0", // Hover effect for rows
              },
            }}
            rows={customers}
            columns={columns}
            pageSize={10}
            rowsPerPageOptions={[15, 20, 30]}
            autoHeight
            disableColumnMenu
            disableSelectionOnClick
          />
        </Paper>
      </Box>
    );
  }
}
