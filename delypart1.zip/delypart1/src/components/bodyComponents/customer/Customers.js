import productList from "../inventory/productList";

const generateOrders = () => {
  const orders = [];
  for (let i = 1; i <= 20; i++) {
    orders.push({
      id: i,
      firstName: i === 2 ? "" : "userr22",
      lastName: "ali",
      position: "Software Engineer",
      mobile: "+92 303345565",
      orders: [{
        id: 1,
        products: productList.slice(0, 3).map((product, index) => ({
          quantity: 5,
          product: product
        }))
      }]
    });
  }
  return orders;
};

const customers = generateOrders();

export default customers;
