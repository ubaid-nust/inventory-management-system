import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  CircularProgress,
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
} from '@mui/material';

// Error Boundary Component
class ErrorBoundary extends React.Component {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, info) {
    console.error('Error caught in Error Boundary:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <Typography variant="h6" color="error">
          Something went wrong with the Order List!
        </Typography>
      );
    }
    return this.props.children;
  }
}

// OrderList Component
const OrderList = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await axios.get('http://localhost:4000/api/orders');
        setOrders(response.data);
      } catch (err) {
        setError('Failed to fetch orders');
        console.error('Error fetching orders:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchOrders();
  }, []);

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh">
        <Typography variant="h6" color="error">
          {error}
        </Typography>
      </Box>
    );
  }

  return (
    <TableContainer component={Paper} sx={{ maxWidth: '90%', margin: 'auto', marginTop: 3 }}>
      <Typography variant="h4" align="center" gutterBottom>
        Order List
      </Typography>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Order ID</TableCell>
            <TableCell>Customer Name</TableCell>
            <TableCell>Mobile</TableCell>
            <TableCell>Products</TableCell>
            <TableCell>Total Price</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {orders.map((order) => (
            <TableRow key={order.id}>
              <TableCell>{order.id}</TableCell>
              <TableCell>{`${order.customer.firstName} ${order.customer.lastName}`}</TableCell>
              <TableCell>{order.customer.mobile}</TableCell>
              <TableCell>
                <ul>
                  {order.products.map((product, index) => (
                    <li key={index}>
                      {product.name} - {product.quantity} × ${product.price.toFixed(2)}
                    </li>
                  ))}
                </ul>
              </TableCell>
              <TableCell>{`$${order.total.toFixed(2)}`}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

// Wrapping the OrderList in an Error Boundary
const OrderListWithErrorBoundary = () => (
  <ErrorBoundary>
    <OrderList />
  </ErrorBoundary>
);

export default OrderListWithErrorBoundary;
