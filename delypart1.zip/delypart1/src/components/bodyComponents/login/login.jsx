import { useState } from 'react';
import { TextField, Button, Box, Typography } from '@mui/material';
import FacebookIcon from '@mui/icons-material/Facebook';
import GoogleIcon from '@mui/icons-material/Google';

function Login() {
  const [loginData, setLoginData] = useState({ emailOrPhone: '', password: '' });

  const handleChange = (event) => {
    setLoginData({ ...loginData, [event.target.name]: event.target.value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log('Login Data:', loginData);
    // Here you would typically handle the login logic, possibly sending the data to a server
  };

  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ mt: 1 }}>
      <TextField
        margin="normal"
        required
        fullWidth
        id="emailOrPhone"
        label="Email Address or Phone Number"
        name="emailOrPhone"
        autoComplete="email"
        autoFocus
        value={loginData.emailOrPhone}
        onChange={handleChange}
      />
      <TextField
        margin="normal"
        required
        fullWidth
        name="password"
        type="password"
        id="password"
        label="Password"
        autoComplete="current-password"
        value={loginData.password}
        onChange={handleChange}
      />
      <Button
        type="submit"
        fullWidth
        variant="contained"
        sx={{ mt: 3, mb: 2 }}
      >
        Sign In
      </Button>
      <Typography component="div" sx={{ mt: 2, mb: 2, textAlign: 'center' }}>
        Or sign in with
      </Typography>
      <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
        <Button variant="outlined" startIcon={<FacebookIcon />} onClick={() => console.log('Login with Facebook')}>
          Facebook
        </Button>
        <Button variant="outlined" startIcon={<GoogleIcon />} onClick={() => console.log('Login with Google')}>
          Google
        </Button>
      </Box>
    </Box>
  );
}

export default Login;
