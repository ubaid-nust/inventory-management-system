import { Box } from "@mui/material";
import React, { useEffect, useState } from "react";
import ApexCharts from "react-apexcharts";
import axios from "axios";

export default function TotalSales() {
  const [salesData, setSalesData] = useState(null); // State to hold fetched sales data
  const [loading, setLoading] = useState(true); // State to handle loading
  const [error, setError] = useState(null); // State to handle errors

  // Options for the chart
  const options = {
    title: {
      text: "Total Sales",
      align: "left",
      style: {
        fontSize: "16px",
        color: "#666",
      },
    },
    subtitle: {
      text: "Sales over time",
      align: "left",
      style: {
        fontSize: "16px",
        color: "#666",
      },
    },
    stroke: {
      curve: "smooth",
      width: 3,
    },
    legend: {
      customLegendItems: [
        "Current Week  <b>$31,000<b/>",
        "Previous Week <b>$37,000<b/>",
      ],
      position: "top",
      horizontalAlign: "center",
      fontSize: "14px",
      fontFamily: "Helvetica, Arial",
      offsetY: -20,
    },
    markers: {
      size: 4,
      strokeWidth: 2,
      hover: {
        size: 9,
      },
    },
    theme: {
      mode: "light",
    },
    chart: {
      height: 328,
      type: "line",
      zoom: {
        enabled: true,
      },
      dropShadow: {
        enabled: true,
        top: 3,
        left: 2,
        blur: 4,
        opacity: 0.2,
      },
    },
    xaxis: {
      categories: salesData ? salesData.categories : [],
    },
  };

  const series = salesData
    ? [
        {
          type: "line",
          name: "Series 1",
          data: salesData.salesData.series1,
        },
        {
          name: "Series 2",
          data: salesData.salesData.series2,
        },
      ]
    : [];

  // Fetch sales data from the backend
  useEffect(() => {
    const fetchSalesData = async () => {
      try {
        const response = await axios.get("http://localhost:4000/api/sales");
        if (response.data.length > 0) {
          setSalesData(response.data[0]); // Set the first entry as the default sales data
        }
        setLoading(false);
      } catch (error) {
        setError("Error fetching sales data.");
        setLoading(false);
      }
    };

    fetchSalesData();
  }, []);

  // Sample POST request data for sales
  const postData = {
    title: "New Sales Data",
    subtitle: "Sales over time",
    currentWeek: 30000,
    previousWeek: 34000,
    salesData: {
      series1: [2500, 3300, 3500, 4000, 4500, 5000, 3700],
      series2: [2000, 2500, 2300, 2800, 3000, 3400, 2900],
    },
    categories: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
  };

  // Function to post new sales data
  const postSalesData = async () => {
    try {
      await axios.post("http://localhost:4000/api/sales", postData);
      alert("Sales data added successfully");
    } catch (error) {
      alert("Failed to add sales data");
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <Box
      sx={{
        margin: 3,
        bgcolor: "white",
        borderRadius: 2,
        padding: 3,
        height: "100%",
      }}
    >
      <ApexCharts
        options={options}
        series={series}
        height={300}
        type="line"
        width="100%"
      />
      {/* Button to post new sales data */}
      <button onClick={postSalesData}>Post New Sales Data</button>
    </Box>
  );
}
