import React, { useEffect, useState } from "react";
import { Box } from "@mui/material";
import ApexCharts from "react-apexcharts";
import axios from "axios";

export default function SalesByCity() {
  const [salesData, setSalesData] = useState([]);
  
  // Fetch sales data from backend
  const fetchSalesData = async () => {
    try {
      const response = await axios.get("http://localhost:4000/sales");
      setSalesData(response.data);
    } catch (error) {
      console.error("Error fetching sales data", error);
    }
  };

  // Run fetchSalesData on component mount
  useEffect(() => {
    fetchSalesData();
  }, []);

  // Calculate total sales
  const totalSales = salesData.reduce((sum, data) => sum + data.sales, 0);

  // Calculate percentages
  const percentages = salesData.map((data) => ((data.sales / totalSales) * 100).toFixed(2));

  // Prepare data for chart
  const labels = salesData.map((data) => data.city);
  const donutSeries = salesData.map((data) => data.sales);

  // Prepare the legend items dynamically
  const customLegendItems = labels.map((label, index) => {
    return `${label} <b>${percentages[index]}%</b>`;
  });

  const donutOption = {
    labels: labels,
    legend: {
      position: "right",
      fontSize: "14",
      customLegendItems: customLegendItems, // Use dynamically calculated legend items
    },
    title: {
      text: "Sales By City",
    },
  };

  return (
    <Box
      sx={{
        margin: 3,
        bgcolor: "white",
        borderRadius: 2,
        padding: 3,
        height: "100%",
      }}
    >
      <ApexCharts
        options={donutOption}
        series={donutSeries}
        type="pie"
        width="100%"
      />
    </Box>
  );
}
