import React, { Component } from "react";
import { Box, Grid } from "@mui/material";

import UilReceipt from "@iconscout/react-unicons/icons/uil-receipt";
import UilBox from "@iconscout/react-unicons/icons/uil-box";
import UilTruck from "@iconscout/react-unicons/icons/uil-truck";
import UilCheckCircle from "@iconscout/react-unicons/icons/uil-check-circle";
import InfoCard from "../../subComponents/InfoCard";
import TotalSales from "./TotalSales";
import SalesByCity from "./SalesByCity";
import Channels from "./Channels";
import TopSellingProduct from "./TopSellingProduct";

export default class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
      cardComponent: [],
      totalSalesData: {}, // Placeholder if extended functionality is needed
      salesByCityData: {}, // Placeholder for additional sections
    };
  }

  componentDidMount() {
    // Fetch dashboard data from the backend
    fetch("http://localhost:4000/api/dashboard")
      .then((response) => response.json())
      .then((data) => {
        this.setState({
          cardComponent: data, // Directly map the fetched array
        });
      })
      .catch((error) => {
        console.error("Error fetching dashboard data:", error);
      });
  }

  render() {
    const { cardComponent } = this.state;

    return (
      <Box
        sx={{
          margin: 0,
          padding: 3,
        }}
      >
        {/* Dashboard Cards */}
        <Grid
          container
          sx={{
            display: "flex",
            justifyContent: "space-between",
            marginX: 3,
            borderRadius: 2,
            padding: 0,
          }}
        >
          {cardComponent.map((card, index) => {
            const IconComponent = {
              "uil-box": <UilBox size={60} color={"#F6F4EB"} />,
              "uil-truck": <UilTruck size={60} color={"#F6F4EB"} />,
              "uil-check-circle": <UilCheckCircle size={60} color={"#F6F4EB"} />,
              "uil-receipt": <UilReceipt size={60} color={"#F6F4EB"} />,
            }[card.icon];

            return (
              <Grid item md={3} key={index}>
                <InfoCard card={{ ...card, icon: IconComponent }} />
              </Grid>
            );
          })}
        </Grid>

        {/* Additional Components */}
        <Grid container sx={{ marginX: 3 }}>
          <Grid item md={8}>
            <TotalSales data={this.state.totalSalesData} />
          </Grid>
          <Grid item md={4}>
            <SalesByCity data={this.state.salesByCityData} />
          </Grid>
        </Grid>

        <Grid container sx={{ margin: 3 }}>
          <Grid item md={6}>
            <Channels />
          </Grid>
          <Grid item md={6}>
            <TopSellingProduct />
          </Grid>
        </Grid>
      </Box>
    );
  }
}
