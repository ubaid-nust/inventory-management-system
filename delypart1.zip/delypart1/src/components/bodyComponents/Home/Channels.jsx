import React, { useEffect, useState } from "react";
import ApexCharts from "react-apexcharts";
import { Box } from "@mui/material";

export default function Channels() {
  const [channelData, setChannelData] = useState([]);

  // Fetch channel data from the backend
  useEffect(() => {
    fetch("http://localhost:4000/api/channels")
      .then((response) => response.json())
      .then((data) => {
        // Transform data into the structure expected by ApexCharts
        const formattedData = data.map((item) => ({
          name: item.name,
          data: item.data,
        }));
        setChannelData(formattedData);
      })
      .catch((error) => {
        console.error("Error fetching channel data:", error);
      });

    return () => {
      setChannelData([]);
    };
  }, []);

  let totalArray = [];
  channelData.forEach((value) => {
    const data = value.data;
    if (totalArray.length === 0) totalArray = [...data];
    else {
      data.forEach((val, index) => (totalArray[index] += val));
    }
  });

  const options3 = {
    chart: {
      id: "basic-bar",
      type: "bar",
      stacked: true,
    },
    dataLabels: {
      enabled: false,
    },
    legend: {
      position: "right",
      horizontalAlign: "center",
      offsetY: 0,
    },
    title: {
      text: "Channels",
    },
    plotOptions: {
      bar: {
        columnWidth: "10%",
        horizontal: false,
      },
    },
    fill: {
      opacity: 1,
    },
    xaxis: {
      categories: ["Mon", "Thu", "Wed", "The", "Fri", "Sat", "Sun"],
    },
  };

  return (
    <Box
      sx={{
        margin: 3,
        bgcolor: "white",
        borderRadius: 2,
        padding: 3,
        height: "95%",
      }}
    >
      <ApexCharts
        options={options3}
        series={channelData}
        type="bar"
        width="100%"
        height="320"
      />
    </Box>
  );
}
