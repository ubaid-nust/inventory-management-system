import React, { useState } from 'react';
import { TextField, Button, Box, Typography, Link } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const Auth = () => {
  const [isSignUp, setIsSignUp] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phoneNumber: ''
  });
  const navigate = useNavigate();

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      let response;
      let url = isSignUp ? 'http://localhost:4000/signup' : 'http://localhost:4000/signin';
      let requestBody = isSignUp
        ? formData
        : { email: formData.email, password: formData.password };

      response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody),
      });

      const data = await response.json();
      console.log('Response from server:', data);

      if (response.ok) {
        // Store the token in localStorage for authentication
        if (!isSignUp) {
          localStorage.setItem('token', data.token);
        }
        navigate('/'); // Redirect to home page on success
      } else {
        alert(data.message || 'Something went wrong!');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Something went wrong!');
    }
  };

  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ mt: 1 }}>
      <Typography variant="h4" gutterBottom>{isSignUp ? 'Sign Up' : 'Sign In'}</Typography>

      {isSignUp && (
        <TextField
          margin="normal"
          required
          fullWidth
          id="name"
          label="Name"
          name="name"
          autoFocus
          value={formData.name}
          onChange={handleChange}
        />
      )}

      <TextField
        margin="normal"
        required
        fullWidth
        id="email"
        label="Email Address"
        name="email"
        value={formData.email}
        onChange={handleChange}
      />
      <TextField
        margin="normal"
        required
        fullWidth
        name="password"
        type="password"
        id="password"
        label="Password"
        value={formData.password}
        onChange={handleChange}
      />
      {isSignUp && (
        <TextField
          margin="normal"
          required
          fullWidth
          id="phoneNumber"
          label="Phone Number"
          name="phoneNumber"
          value={formData.phoneNumber}
          onChange={handleChange}
        />
      )}

      <Button
        type="submit"
        fullWidth
        variant="contained"
        sx={{ mt: 3, mb: 2 }}
      >
        {isSignUp ? 'Sign Up' : 'Sign In'}
      </Button>

      <Box display="flex" justifyContent="center">
        <Link
          href="#"
          onClick={() => setIsSignUp(!isSignUp)}
          variant="body2"
        >
          {isSignUp ? "Already have an account? Sign In" : "Don't have an account? Create One?"}
        </Link>
      </Box>
    </Box>
  );
};

export default Auth;
