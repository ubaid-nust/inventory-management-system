import React, { Component } from "react";
import { Table, Card, Row, Col, Button, Spinner } from "react-bootstrap"; // Importing some more components for a cleaner UI
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

export default class Report extends Component {
  state = {
    products: [],
    topSellingProducts: [],
    revenueCost: [],
    bestWeeklyProducts: [],
    bestYearlyProducts: [],
    loading: true,
    error: null,
  };

  async componentDidMount() {
    try {
      const [
        productsRes,
        topSellingRes,
        revenueCostRes,
        weeklyRes,
        yearlyRes,
      ] = await Promise.all([
        fetch("http://localhost:4000/products").then((res) => res.json()),
        fetch("http://localhost:4000/api/top-selling-products").then((res) => res.json()),
        fetch("http://localhost:4000/revenueCost").then((res) => res.json()),
        fetch("http://localhost:4000/bestSelledProductWeekly").then((res) => res.json()),
        fetch("http://localhost:4000/bestSelledProductYearly").then((res) => res.json()),
      ]);

      this.setState({
        products: productsRes,
        topSellingProducts: topSellingRes,
        revenueCost: revenueCostRes,
        bestWeeklyProducts: weeklyRes,
        bestYearlyProducts: yearlyRes,
        loading: false,
      });
    } catch (error) {
      this.setState({ error: error.message, loading: false });
    }
  }

  render() {
    const {
      products,
      topSellingProducts,
      revenueCost,
      bestWeeklyProducts,
      bestYearlyProducts,
      loading,
      error,
    } = this.state;

    if (loading) return <div className="loading-spinner"><Spinner animation="border" variant="primary" /></div>;
    if (error) return <div>Error: {error}</div>;

    return (
      <div className="report-container">
        <h1 className="text-center my-4">Reports</h1>

        {/* Product List Section */}
        <Card className="mb-4">
          <Card.Body>
            <Card.Title className="text-center">All Products</Card.Title>
            <Table striped bordered hover responsive variant="dark">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Category</th>
                  <th>Price</th>
                  <th>Stock</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {products.map((product) => (
                  <tr key={product.id}>
                    <td>{product.id}</td>
                    <td>{product.name}</td>
                    <td>{product.category}</td>
                    <td>${product.price}</td>
                    <td>{product.stock}</td>
                    <td>
                      <Button variant="info" size="sm">Details</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Card.Body>
        </Card>

        {/* Top Selling Products Section */}
        <Card className="mb-4">
          <Card.Body>
            <Card.Title className="text-center">Top Selling Products</Card.Title>
            <Table striped bordered hover responsive variant="dark">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Price</th>
                  <th>Quantity</th>
                  <th>Total Amount</th>
                </tr>
              </thead>
              <tbody>
                {topSellingProducts.map((product, index) => (
                  <tr key={index}>
                    <td>{product.name}</td>
                    <td>${product.price}</td>
                    <td>{product.quantity}</td>
                    <td>${product.amount}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Card.Body>
        </Card>

        {/* Revenue vs Cost Chart */}
        <Card className="mb-4">
          <Card.Body>
            <Card.Title className="text-center">Revenue vs Cost</Card.Title>
            <BarChart width={600} height={300} data={revenueCost}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="revenue" fill="#82ca9d" />
              <Bar dataKey="cost" fill="#8884d8" />
            </BarChart>
          </Card.Body>
        </Card>

        {/* Best Selling Products Weekly */}
        <Card className="mb-4">
          <Card.Body>
            <Card.Title className="text-center">Best Selling Products (Weekly)</Card.Title>
            <LineChart width={600} height={300} data={bestWeeklyProducts}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="data" stroke="#8884d8" />
            </LineChart>
          </Card.Body>
        </Card>

        {/* Best Selling Products Yearly */}
        <Card className="mb-4">
          <Card.Body>
            <Card.Title className="text-center">Best Selling Products (Yearly)</Card.Title>
            <LineChart width={600} height={300} data={bestYearlyProducts}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="data" stroke="#82ca9d" />
            </LineChart>
          </Card.Body>
        </Card>
      </div>
    );
  }
}
