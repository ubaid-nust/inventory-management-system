import React, { useEffect, useState } from "react";
import { DataGrid } from "@mui/x-data-grid";
import axios from "axios";
import Product from "./Product"; // Assuming you have a Product component

export default function Products() {
  const [products, setProducts] = useState([]); // State to store fetched products
  const [loading, setLoading] = useState(true); // State for loading indicator
  const [error, setError] = useState(null); // State for error handling

  // Fetch products data from the backend
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get("http://localhost:4000/products");
        setProducts(response.data); // Store fetched products in state
        setLoading(false); // Set loading to false once data is fetched
      } catch (error) {
        setError("Error fetching products data.");
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  const columns = [
    {
      field: "id",
      headerName: "ID",
      width: 90,
      description: "ID of the product",
    },
    {
      field: "name",
      headerName: "Product",
      width: 400,
      description: "Name of the product",
      renderCell: (cellData) => {
        return <Product productName={cellData.row.name} />;
      },
    },
    {
      field: "category",
      headerName: "Category",
      width: 200,
      description: "Category of the product",
    },
    {
      field: "price",
      headerName: "Price",
      width: 150,
      description: "Price of the product",
      valueGetter: (params) => "$" + params.row.price.toFixed(2),
    },
    {
      field: "stock",
      headerName: "Stock",
      width: 200,
      description: "How many items in the stock",
      valueGetter: (params) => params.row.stock + " pcs",
    },
  ];

  const rows = products.map((product, index) => ({
    id: product.id, // Assuming '_id' is the unique identifier
    name: product.name,
    category: product.category,
    price: product.price,
    stock: product.stock,
  }));

  return (
    <div>
      <DataGrid
        sx={{ borderLeft: 0, borderRight: 0, borderRadius: 0 }}
        rows={rows}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: { page: 0, pageSize: 10 },
          },
        }}
        pageSizeOptions={[5, 10, 20]}
        checkboxSelection
      />
    </div>
  );
}
