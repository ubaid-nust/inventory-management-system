const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config(); // Ensure this is loaded

const app = express();
const port = 4000;

mongoose.set('debug', true);

// Middleware
app.use(cors());
app.use(express.json());

// Connect to MongoDB
(async () => {
  try {
    await mongoose.connect(
      "mongodb+srv://ubaid:6734%23ubaid%24@mycluster.7etnm.mongodb.net/?retryWrites=true&w=majority&appName=MyCluster",
    );
    console.log("Connected to MongoDB.");
  } catch (error) {
    console.error("Database connection error:", error);
    process.exit(1); // Exit on failure
  }
})();

// User Schema
const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  phoneNumber: { type: String, required: true }
});

// Hash password before saving the user
UserSchema.pre('save', async function(next) {
  if (this.isModified('password')) {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
  }
  next();
});

// Method to compare passwords
UserSchema.methods.matchPassword = async function(enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

const User = mongoose.model('User', UserSchema);

// SignUp Endpoint
app.post('/signup', async (req, res) => {
  const { name, email, password, phoneNumber } = req.body;

  try {
    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ message: 'User already exists' });
    }

    const user = new User({ name, email, password, phoneNumber });
    await user.save();

    res.status(201).json({ message: 'User registered successfully' });
  } catch (error) {
    console.error('Error during sign-up:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// SignIn Endpoint
app.post('/signin', async (req, res) => {
  const { email, password } = req.body;

  try {
    // Check if user exists
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    // Check if passwords match
    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    // Generate JWT token
    const token = jwt.sign(
      { id: user._id },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    // Return response with token and user info
    res.json({
      token,
      user: { id: user._id, email: user.email, name: user.name },
      message: 'Login successful',
    });
  } catch (error) {
    console.error('Error during sign-in:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// LogOut Endpoint
app.get('/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ message: 'Logged out successfully' });
});

// Schema and Model
const DashboardSchema = new mongoose.Schema({
  icon: { type: String, required: true },
  title: { type: String, required: true },
  subTitle: { type: String, required: true },
  mx: { type: Number, required: true },
  my: { type: Number, required: true },
});

const Dashboard = mongoose.model("Dashboard", DashboardSchema);

// Routes

// GET dashboard data
app.get("/api/dashboard", async (req, res) => {
  try {
    const dashboardData = await Dashboard.find();
    res.json(dashboardData);
  } catch (error) {
    console.error("Error fetching dashboard data:", error);
    res.status(500).json({ error: "Failed to fetch dashboard data" });
  }
});

// POST new dashboard entry
app.post("/api/dashboard", async (req, res) => {
  try {
    const { icon, title, subTitle, mx, my } = req.body;
    const newDashboardEntry = new Dashboard({ icon, title, subTitle, mx, my });
    await newDashboardEntry.save();
    res.status(201).json({ message: "Dashboard entry created successfully" });
  } catch (error) {
    console.error("Error adding dashboard entry:", error);
    res.status(500).json({ error: "Failed to add dashboard entry" });
  }
});

// Define Schema and Model
const ChannelSchema = new mongoose.Schema({
  name: { type: String, required: true },
  data: { type: [Number], required: true },
});

const Channel = mongoose.model("Channel", ChannelSchema);

// Routes

// GET method to fetch all channel data
app.get("/api/channels", async (req, res) => {
  try {
    const channelData = await Channel.find();
    res.json(channelData);
  } catch (error) {
    console.error("Error fetching channel data:", error);
    res.status(500).json({ error: "Failed to fetch channel data" });
  }
});

// POST method to add new channel data
app.post("/api/channels", async (req, res) => {
  try {
    const { name, data } = req.body;
    const newChannel = new Channel({ name, data });
    await newChannel.save();
    res.status(201).json({ message: "Channel data added successfully" });
  } catch (error) {
    console.error("Error adding channel data:", error);
    res.status(500).json({ error: "Failed to add channel data" });
  }
});

const SalesSchema = new mongoose.Schema({
  title: { type: String, required: true },
  subtitle: { type: String, required: true },
  currentWeek: { type: Number, required: true },
  previousWeek: { type: Number, required: true },
  salesData: {
    series1: { type: [Number], required: true },
    series2: { type: [Number], required: true },
  },
  categories: { type: [String], required: true },
});

const Sales = mongoose.model("Sales", SalesSchema);

// POST method to add new sales data
app.post("/api/sales", async (req, res) => {
  try {
    const { title, subtitle, currentWeek, previousWeek, salesData, categories } = req.body;
    const newSales = new Sales({ title, subtitle, currentWeek, previousWeek, salesData, categories });
    await newSales.save();
    res.status(201).json({ message: "Sales data added successfully" });
  } catch (error) {
    console.error("Error adding sales data:", error);
    res.status(500).json({ error: "Failed to add sales data" });
  }
});

// GET method to fetch all sales data
app.get("/api/sales", async (req, res) => {
  try {
    const salesData = await Sales.find();
    res.json(salesData);
  } catch (error) {
    console.error("Error fetching sales data:", error);
    res.status(500).json({ error: "Failed to fetch sales data" });
  }
});


const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  price: {
    type: Number,
    required: true,
  },
  quantity: {
    type: Number,
    required: true,
  },
  amount: {
    type: Number,
    required: true,
  },
});

const Product = mongoose.model("Product", productSchema);

const allproducts = new mongoose.Schema({
  id: {
    type: Number,
    required: true,
    unique: true,
  },
  name: {
    type: String,
    required: true,
  },
  category: {
    type: String,
    required: true,
  },
  price: {
    type: Number,
    required: true,
  },
  stock:{
    type: Number,
    required: true
  }
});

const allProducts = mongoose.model("All Products",allproducts);

// POST endpoint to create a new product
app.post('/products', async (req, res) => {
  const { id, name, category, price, stock } = req.body;

  // Check if product already exists
  const existingProduct = await allProducts.findOne({ id });
  if (existingProduct) {
    return res.status(400).json({ message: 'Product with this ID already exists' });
  }

  try {
    const newProduct = new allProducts({
      id,
      name,
      category,
      price,
      stock,
    });

    // Save the new product to the database
    await newProduct.save();
    res.status(201).json(newProduct); // Return the created product
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET endpoint to fetch all products
app.get('/products', async (req, res) => {
  try {
    const products = await allProducts.find();
    res.status(200).json(products); // Return the list of products
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Product Routes
app.get("/api/products", async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (error) {
    console.error("Error fetching products:", error);
    res.status(500).json({ error: "Failed to fetch product data" });
  }
});

// POST method to add new product data
app.post("/api/products", async (req, res) => {
  try {
    const { name, price, quantity, amount } = req.body;
    const newProduct = new Product({ name, price, quantity, amount });
    await newProduct.save();
    res.status(201).json(newProduct); // Return the newly created product
  } catch (error) {
    console.error("Error adding product:", error);
    res.status(500).json({ error: "Failed to add product" });
  }
});

const topSellingProductSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    price: {
      type: Number,
      required: true,
    },
    quantity: {
      type: Number,
      required: true,
    },
    amount: {
      type: Number,
      required: true,
    },
  },
  { timestamps: true }
);

const TopSellingProducts = mongoose.model("TopSellingProduct", topSellingProductSchema);

// GET endpoint to fetch top-selling products
app.get("/api/top-selling-products", async (req, res) => {
  try {
    const products = await TopSellingProducts.find(); // Use TopSellingProducts here
    res.json(products); 
  } catch (error) {
    console.error("Error fetching top-selling products:", error);
    res.status(500).json({ error: "Failed to fetch top-selling products" });
  }
});

// POST endpoint to add a new top-selling product
app.post("/api/top-selling-products", async (req, res) => {
  try {
    const { name, price, quantity, amount } = req.body;

    const newProduct = new TopSellingProducts({
      name,
      price,
      quantity,
      amount,
    });

    await newProduct.save(); // Save the new product to the database
    res.status(201).json(newProduct); // Send the newly created product as a response
  } catch (error) {
    console.error("Error adding top-selling product:", error);
    res.status(500).json({ error: "Failed to add top-selling product" });
  }
});

const salesDataSchema = new mongoose.Schema({
  city: { type: String, required: true },
  sales: { type: Number, required: true }
});

const SalesData = mongoose.model("SalesData", salesDataSchema);

app.post("/sales", async (req, res) => {
  try {
    const { city, sales } = req.body;
    const newSalesData = new SalesData({ city, sales });
    await newSalesData.save();
    res.status(201).send(newSalesData);
  } catch (error) {
    res.status(400).send({ message: "Error adding sales data", error });
  }
});

// GET endpoint to retrieve sales data
app.get("/sales", async (req, res) => {
  try {
    const salesData = await SalesData.find();
    res.status(200).send(salesData);
  } catch (error) {
    res.status(500).send({ message: "Error fetching sales data", error });
  }
});


const orderSchema = new mongoose.Schema({
  customerId: { type: Number, ref: "Customer", required: true }, // Use 'Number' for customer ID
  products: [
    {
      name: { type: String, required: true },
      quantity: { type: Number, required: true },
      price: { type: Number, required: true },
    },
  ],
  totalPrice: { type: Number, required: true },
  orderDate: { type: Date, default: Date.now },
});

const Order = mongoose.model("Order", orderSchema);

// Customer Schema
const customerSchema = new mongoose.Schema({
  id: { type: Number, required: true, unique: true }, // Customer's ID field
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  position: { type: String, required: true },
  mobile: { type: String, required: true },
  orders: [{ type: mongoose.Schema.Types.ObjectId, ref: "Order" }],
});

const Customer = mongoose.model("Customer", customerSchema);

// GET all customers
app.get("/api/customers", async (req, res) => {
  try {
    const customers = await Customer.find();
    res.status(200).json(customers);
  } catch (error) {
    console.error("Error fetching customers:", error);
    res.status(500).json({ error: "Failed to fetch customers" });
  }
});

// POST a new customer
app.post("/api/customers", async (req, res) => {
  try {
    const { id, firstName, lastName, position, mobile } = req.body;

    if (!id || !firstName || !lastName || !position || !mobile) {
      return res.status(400).json({ error: "All fields are required." });
    }

    const existingCustomer = await Customer.findOne({ id });
    if (existingCustomer) {
      return res.status(400).json({ error: "Customer with this ID already exists." });
    }

    const newCustomer = new Customer({ id, firstName, lastName, position, mobile });
    await newCustomer.save();

    res.status(201).json({ message: "Customer added successfully", customer: newCustomer });
  } catch (error) {
    console.error("Error adding customer:", error);
    res.status(500).json({ error: "Failed to add customer" });
  }
});

// GET all orders
app.get("/api/orders", async (req, res) => {
  try {
    const orders = await Order.find().lean();

    const enrichedOrders = await Promise.all(
      orders.map(async (order) => {
        try {
          // Find the customer by 'id'
          const customer = await Customer.findOne({ id: order.customerId });
          if (!customer) {
            console.error(`Customer not found for order ${order._id}`);
            return null;
          }

          // Include customer details and product details
          return {
            id: order._id,
            customer: {
              firstName: customer.firstName,
              lastName: customer.lastName,
              mobile: customer.mobile,
            },
            products: order.products.map((product) => ({
              name: product.name,
              quantity: product.quantity,
              price: product.price,
            })), // Include the products array
            total: order.totalPrice,
          };
        } catch (error) {
          console.error(`Error fetching customer for order ${order._id}:`, error);
          return null; // Handle missing customer data
        }
      })
    );

    // Filter out null values (in case of errors or missing customers)
    res.status(200).json(enrichedOrders.filter(Boolean));
  } catch (error) {
    console.error("Error occurred while fetching orders:", error);
    res.status(500).json({ error: "Failed to fetch orders" });
  }
});

// POST a new order
app.post("/api/orders", async (req, res) => {
  try {
    const { customerId, products } = req.body;

    if (!customerId || !products || !products.length) {
      return res.status(400).json({ error: "Missing customerId or product list." });
    }

    // Check if the customer exists by ID
    const existingCustomer = await Customer.findOne({ id: customerId });
    if (!existingCustomer) {
      return res.status(404).json({ error: "Customer not found." });
    }

    // Check if each product exists by name
    const enrichedProducts = await Promise.all(
      products.map(async (productEntry) => {
        try {
          const { name, quantity } = productEntry;
          if (!name || !quantity) {
            throw new Error("Product object is missing required fields.");
          }

          const product = await allProducts.findOne({ name });
          if (!product) {
            throw new Error(`Product with name "${name}" not found.`);
          }

          return { name, quantity, price: product.price };
        } catch (error) {
          console.error(error);  // Log the error
          return null;  // You could choose to return a default or skip this product
        }
      })
    );

    // Filter out invalid products
    const validProducts = enrichedProducts.filter(Boolean);

    // Calculate total price
    const totalPrice = validProducts.reduce((total, product) => {
      return total + product.price * product.quantity;
    }, 0);

    // Create the new order
    const newOrder = new Order({ customerId, products: validProducts, totalPrice });
    await newOrder.save();

    res.status(201).json({ message: "Order created successfully", order: newOrder });
  } catch (error) {
    console.error("Error creating order:", error);
    res.status(500).json({ error: error.message });
  }
});

const revenueSchema = new mongoose.Schema({
  isMoney: { type: Boolean, required: true },
  number: { type: String, required: true },
  percentage: { type: Number },
  upOrDown: { type: String, enum: ["up", "down"], required: false },
  color: { type: String, required: false },
  title: { type: String, required: true },
  subTitle: { type: String, required: true },
});

// Create the model for the schema
const Revenue = mongoose.model('Revenue', revenueSchema);

// API routes

// GET route to fetch revenue data
app.get("/revenue", async (req, res) => {
  try {
    const revenues = await Revenue.find(); // Fetch all revenue records from DB
    res.json(revenues); // Send the data as JSON response
  } catch (err) {
    res.status(500).json({ message: err.message }); // Handle errors
  }
});

// POST route to add new revenue data
app.post("/revenue", async (req, res) => {
  try {
    const newRevenue = new Revenue(req.body); // Create a new revenue object from the request body
    await newRevenue.save(); // Save it to the database
    res.status(201).json(newRevenue); // Return the newly created record
  } catch (err) {
    res.status(400).json({ message: err.message }); // Handle errors
  }
});

// ----------------------------------------------------------------
const revenueCostSchema = new mongoose.Schema({
  month: { type: String, required: true },
  revenue: { type: Number, required: true },
  cost: { type: Number, required: true },
});

const RevenueCost = mongoose.model('RevenueCost', revenueCostSchema);

app.post('/api/revenueCost', async (req, res) => {
  try {
    const { month, revenue, cost } = req.body;
    const newData = new RevenueCost({ month, revenue, cost });
    await newData.save();
    res.status(201).json(newData);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

app.get('/revenueCost', async (req, res) => {
  try {
    const data = await RevenueCost.find();
    res.json(data);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

//----------------------------------------------------------

const bestSelledProductSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  data: {
    type: [Number],
    required: true,
  },
});

const BestSelledProduct = mongoose.model("BestSelledProduct", bestSelledProductSchema);

app.post("/bestSelledProductWeekly", async (req, res) => {
  const { name, data } = req.body;

  try {
    const newProduct = new BestSelledProduct({ name, data });
    await newProduct.save();
    res.status(201).json(newProduct);
  } catch (err) {
    res.status(500).json({ message: "Error saving product data", error: err });
  }
});

app.get("/bestSelledProductWeekly", async (req, res) => {
  try {
    const products = await BestSelledProduct.find();
    res.status(200).json(products);
  } catch (err) {
    res.status(500).json({ message: "Error fetching product data", error: err });
  }
});

const bestSelledProductSchemaYearly = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  data: {
    type: [Number],
    required: true,
  },
});

const BestSelledProductYearly = mongoose.model("BestSelledProductYearly", bestSelledProductSchemaYearly);

// POST route to add new product data
app.post("/bestSelledProductYearly", async (req, res) => {
  const { name, data } = req.body;

  try {
    const newProduct = new BestSelledProductYearly({ name, data });
    await newProduct.save();
    res.status(201).json(newProduct);
  } catch (err) {
    res.status(500).json({ message: "Error saving product data", error: err });
  }
});

// GET route to retrieve product data
app.get("/bestSelledProductYearly", async (req, res) => {
  try {
    const products = await BestSelledProductYearly.find();
    res.status(200).json(products);
  } catch (err) {
    res.status(500).json({ message: "Error fetching product data", error: err });
  }
});

const revenueCardSchema = new mongoose.Schema({
  isMoney: { type: Boolean, required: true },
  number: { type: String, required: true },
  percentage: { type: Number, required: true },
  upOrDown: { type: String, enum: ["up", "down"], required: true },
  color: { type: String, required: true },
  title: { type: String, required: true },
  subTitle: { type: String, required: true },
});

const RevenueCard = mongoose.model("RevenueCard", revenueCardSchema);

// POST endpoint to create a revenue card
app.post("/revenue-cards", async (req, res) => {
  try {
    const card = new RevenueCard(req.body);
    await card.save();
    res.status(201).json(card);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// GET endpoint to fetch all revenue cards
app.get("/revenue-cards", async (req, res) => {
  try {
    const cards = await RevenueCard.find();
    res.status(200).json(cards);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

const salesGrowthSchema = new mongoose.Schema({
  name: { type: String, required: true },
  data: { type: [Number], required: true },
  categories: { type: [String], required: true },
});

const SalesGrowth = mongoose.model("SalesGrowth", salesGrowthSchema);

// POST endpoint to create sales growth data
app.post("/sales-growth", async (req, res) => {
  try {
    const { name, data, categories } = req.body;
    const salesData = new SalesGrowth({ name, data, categories });
    await salesData.save();
    res.status(201).json(salesData);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// GET endpoint to fetch sales growth data
app.get("/sales-growth", async (req, res) => {
  try {
    const salesData = await SalesGrowth.findOne();
    res.status(200).json(salesData);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

const visitorGrowthSchema = new mongoose.Schema({
  name: { type: String, required: true }, // Series name (e.g., Active Visitors)
  type: { type: String, default: "column" }, // Chart type
  data: { type: [Number], required: true }, // Data points for the series
  categories: { type: [String], required: true }, // X-axis categories
});

const VisitorGrowth = mongoose.model("VisitorGrowth", visitorGrowthSchema);

// POST endpoint to create visitor growth data
app.post("/visitor-growth", async (req, res) => {
  try {
    const { name, type, data, categories } = req.body;
    const visitorData = new VisitorGrowth({ name, type, data, categories });
    await visitorData.save();
    res.status(201).json(visitorData);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// GET endpoint to fetch visitor growth data
app.get("/visitor-growth", async (req, res) => {
  try {
    const visitorData = await VisitorGrowth.find();
    const categories = visitorData.length ? visitorData[0].categories : [];
    const series = visitorData.map((entry) => ({
      name: entry.name,
      type: entry.type,
      data: entry.data,
    }));

    res.status(200).json({ categories, series });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

const productGrowthSchema = new mongoose.Schema({
  name: { type: String, required: true }, // Series name (e.g., Current Week)
  data: { type: [Number], required: true }, // Data points for the series
  categories: { type: [String], required: true }, // X-axis categories
});

const ProductGrowth = mongoose.model("ProductGrowth", productGrowthSchema);

// POST endpoint to create product growth data
app.post("/product-growth", async (req, res) => {
  try {
    const { name, data, categories } = req.body;
    const productData = new ProductGrowth({ name, data, categories });
    await productData.save();
    res.status(201).json(productData);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// GET endpoint to fetch product growth data
app.get("/product-growth", async (req, res) => {
  try {
    const productData = await ProductGrowth.find();
    const categories = productData.length ? productData[0].categories : [];
    const series = productData.map((entry) => ({
      name: entry.name,
      data: entry.data,
    }));

    res.status(200).json({ categories, series });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

const customerGrowthSchema = new mongoose.Schema({
  name: { type: String, required: true }, // Series name (e.g., Current Week)
  data: { type: [Number], required: true }, // Data points for the series
  categories: { type: [String], required: true }, // X-axis categories
});

const CustomerGrowth = mongoose.model("CustomerGrowth", customerGrowthSchema);

app.post("/customer-growth", async (req, res) => {
  try {
    const { name, data, categories } = req.body;
    const customerData = new CustomerGrowth({ name, data, categories });
    await customerData.save();
    res.status(201).json(customerData);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// GET endpoint to fetch customer growth data
app.get("/customer-growth", async (req, res) => {
  try {
    const customerData = await CustomerGrowth.find();
    const categories = customerData.length ? customerData[0].categories : [];
    const series = customerData.map((entry) => ({
      name: entry.name,
      data: entry.data,
    }));

    res.status(200).json({ categories, series });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Default route
app.get("/", (req, res) => {
  res.send("Backend is running.");
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
